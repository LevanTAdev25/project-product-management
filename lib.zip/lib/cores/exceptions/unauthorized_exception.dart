class UnauthorizedException implements Exception {}
//